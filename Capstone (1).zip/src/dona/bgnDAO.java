package dona;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class bgnDAO {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	//커넥션 풀을 이용한 데이터베이스 연결 메소드 선언
		public void connect_CP() {
			try {
				//1. Context.xml에 접근
				Context initctx = new InitialContext();
				
				//2.source 태그의 name 과 type 속성을 이용하여
				//DataSource 객체 생성
				DataSource ds = (DataSource)initctx.lookup("java:/comp/env/jdbc/pool");
				
				//3. 커넥션 풀에서 커넥션 할당 받기
				con = ds.getConnection();
			}catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//데이터베이스 연결 해제 및 자원 해제
		public void disconnect() {
			//5. 자원 해제
			try {
				if( con != null) con.close();
				if( pstmt != null) pstmt.close();
				if( rs != null) rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//뷰 만들기
		public void setView() {
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql1 = "create or replace view new_bgn as select * from bgn where bgn_startDate >= (select sysdate from dual) order by bgn_num desc";
				String sql2 = "create or replace view end_bgn as select * from bgn where bgn_startDate >= (select sysdate from dual) order by bgn_startDate";
				
				pstmt = con.prepareStatement(sql1);
				pstmt.executeUpdate();
				
				pstmt = con.prepareStatement(sql2);
				pstmt.executeUpdate();
				
				System.out.println("setView() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
		//bgn_num을 이용하여 하나의 주소정보를 리턴하는 메소드
		public bgnBean getOneBgn(int bgn_num) {
			bgnBean abean = new bgnBean();
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "select * from bgn where bgn_num=?";
				pstmt = con.prepareStatement(sql);
				
				//3_1. ?실행
				pstmt.setInt(1, bgn_num);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
					//ado 어레이리스트에 클래스 저장
					abean.setBgn_num(rs.getInt("bgn_num"));
					abean.setC_num(rs.getInt("c_num"));
					abean.setBgn_title(rs.getString("bgn_title"));
					abean.setBgn_content(rs.getString("bgn_content"));
					abean.setBgn_image(rs.getString("bgn_image"));
					abean.setBgn_link(rs.getString("bgn_link"));
					abean.setBgn_startDate(rs.getString("bgn_startDate"));
					abean.setBgn_endDate(rs.getString("bgn_endDate"));
				}
				System.out.println("getOneAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return abean;
		}
		
		
		public ArrayList<bgnBean> getSearchG(int now_page, String pos,String s) {
			if(pos.equals("new_bgn")) {
				pos = "order by bgn_num desc";
			}else if(pos.equals("end_bgn")) {
				pos = "order by bgn_num asc";
			}
			
			ArrayList<bgnBean> bList = new ArrayList<>();
			int startNum = ((now_page-1)*12) + 1;
			int endNum = now_page*12;
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql;
				sql = "select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate, bgn_comp from bgn WHERE bgn_title LIKE '%" + s + "%' and c_num between 11 and 14 "+pos+") a where a.num between ? and ?";
				
				pstmt = con.prepareStatement(sql);

				//3_1. ?실행
				//pstmt.setString(1, s);
				pstmt.setInt(1, startNum);
				pstmt.setInt(2, endNum);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
					//ado 어레이리스트에 클래스 저장
					bgnBean bgnbean = new bgnBean();
					bgnbean.setBgn_num(rs.getInt("bgn_num"));
					bgnbean.setC_num(rs.getInt("c_num"));
					bgnbean.setBgn_title(rs.getString("bgn_title"));
					bgnbean.setBgn_content(rs.getString("bgn_content"));
					bgnbean.setBgn_image(rs.getString("bgn_image"));
					bgnbean.setBgn_link(rs.getString("bgn_link"));
					bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
					bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
					bgnbean.setBgn_comp(rs.getString("bgn_comp"));
					
					bList.add(bgnbean);
				}
				System.out.println("getOneAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return bList;
		}
		
		



		public int getCountB(String s) {
			int c = 0;
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "SELECT count(*) FROM new_bgn WHERE bgn_title LIKE '%" + s + "%' and c_num between 1 and 4";
				pstmt = con.prepareStatement(sql);

				//3_1. ?실행
				//pstmt.setString(1, s);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					c = rs.getInt("count(*)");
					System.out.println("count() : " + c);
				}
				System.out.println("getOneAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return c;
		}	
		
		public int getCountG(String s) {
			int c = 0;
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "SELECT count(*) FROM bgn WHERE bgn_title LIKE '%" + s + "%' and c_num between 11 and 14";
				pstmt = con.prepareStatement(sql);

				//3_1. ?실행
				//pstmt.setString(1, s);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					c = rs.getInt("count(*)");
					System.out.println("count() : " + c);
				}
				System.out.println("getOneAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return c;
		}		
		
		public ArrayList<bgnBean> getSearchBD(int now_page, String pos,String s,int n) {
			ArrayList<bgnBean> bList = new ArrayList<>();
			int startNum = ((now_page-1)*12) + 1;
			int endNum = now_page*12;
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate from " + pos + " where c_num=? and bgn_title LIKE '%" + s + "%') a where a.num between ? and ?";
				pstmt = con.prepareStatement(sql);

				//3_1. ?실행
				pstmt.setInt(1, n);
				pstmt.setInt(2, startNum);
				pstmt.setInt(3, endNum);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
					//ado 어레이리스트에 클래스 저장
					bgnBean bgnbean = new bgnBean();
					bgnbean.setBgn_num(rs.getInt("bgn_num"));
					bgnbean.setC_num(rs.getInt("c_num"));
					bgnbean.setBgn_title(rs.getString("bgn_title"));
					bgnbean.setBgn_content(rs.getString("bgn_content"));
					bgnbean.setBgn_image(rs.getString("bgn_image"));
					bgnbean.setBgn_link(rs.getString("bgn_link"));
					bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
					bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
					
					bList.add(bgnbean);
				}
				System.out.println("getOneAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return bList;
		}
		
		public int getCountBD(String s,int n) {
			int c = 0;
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "SELECT count(*) FROM new_bgn WHERE bgn_title LIKE '%" + s + "%' and c_num=?";
				pstmt = con.prepareStatement(sql);

				//3_1. ?실행
				pstmt.setInt(1, n);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					c = rs.getInt("count(*)");
					System.out.println("count() : " + c);
				}
				System.out.println("getOneAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return c;
		}
		
		//전체 화면에서 검색
		public ArrayList<bgnBean> getSearchAll(int n, String s) {
			int startNum = 0;
			int endNum = 0;
			if(n == 1) {
				startNum = 1;endNum = 4;
			}else if(n == 2) {
				startNum = 11;endNum = 14;
			}
			ArrayList<bgnBean> bList = new ArrayList<>();
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "select * from new_bgn where (bgn_title like '%" + s + "%') and (c_num between ? and ?) and (rownum between 1 and 4) order by bgn_num desc";
				pstmt = con.prepareStatement(sql);
				
				//3_1. ?실행
				pstmt.setInt(1, startNum);
				pstmt.setInt(2, endNum);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
					//ado 어레이리스트에 클래스 저장
					bgnBean bgnbean = new bgnBean();
					bgnbean.setBgn_num(rs.getInt("bgn_num"));
					bgnbean.setC_num(rs.getInt("c_num"));
					bgnbean.setBgn_title(rs.getString("bgn_title"));
					bgnbean.setBgn_content(rs.getString("bgn_content"));
					bgnbean.setBgn_image(rs.getString("bgn_image"));
					bgnbean.setBgn_link(rs.getString("bgn_link"));
					bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
					bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
					bgnbean.setBgn_comp(rs.getString("bgn_comp"));
					
					bList.add(bgnbean);
				}
				System.out.println("getOneAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return bList;
		}
		//전체 화면에서 검색 봉사페이지
				public ArrayList<bgnBean> getSearchAllD(int now_page, String pos, String s) {
					ArrayList<bgnBean> bList = new ArrayList<>();
					int startNum = ((now_page-1)*12) + 1;
					int endNum = now_page*12;
					//1.데이터베이스 연결
					connect_CP();
					
					//2. SQL실행
					try {
						//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
						String sql = "select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate from bgn WHERE bgn_title LIKE '%" + s + "%' " + pos + ") a where a.num between ? and ?";
						pstmt = con.prepareStatement(sql);

						//3_1. ?실행
						//pstmt.setString(1, s);
						pstmt.setInt(1, startNum);
						pstmt.setInt(2, endNum);
						
						//4. sql문 실행 및 결과
						rs = pstmt.executeQuery();
						while(rs.next()){
							//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
							//ado 어레이리스트에 클래스 저장
							bgnBean bgnbean = new bgnBean();
							bgnbean.setBgn_num(rs.getInt("bgn_num"));
							bgnbean.setC_num(rs.getInt("c_num"));
							bgnbean.setBgn_title(rs.getString("bgn_title"));
							bgnbean.setBgn_content(rs.getString("bgn_content"));
							bgnbean.setBgn_image(rs.getString("bgn_image"));
							bgnbean.setBgn_link(rs.getString("bgn_link"));
					
					bList.add(bgnbean);
				}
				System.out.println("getOneAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return bList;
		}
		
		//bgn_num을 이용하여 하나의 주소정보를 리턴라는 메소드
		public ArrayList<bgnBean> getOnePage(int now_page, String pos) {
			ArrayList<bgnBean> bList = new ArrayList<>();
			int startNum = ((now_page-1)*12) + 1;
			int endNum = now_page*12;
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate from " + pos + " where c_num between 1 and 4) a where a.num between ? and ?";
				//select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate from new_bgn) a where a.num between 12 and 24 ;
				pstmt = con.prepareStatement(sql);
				
				//3_1. ?실행
				pstmt.setInt(1, startNum);
				pstmt.setInt(2, endNum);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
					//ado 어레이리스트에 클래스 저장
					bgnBean bgnbean = new bgnBean();
					bgnbean.setBgn_num(rs.getInt("bgn_num"));
					bgnbean.setC_num(rs.getInt("c_num"));
					bgnbean.setBgn_title(rs.getString("bgn_title"));
					bgnbean.setBgn_content(rs.getString("bgn_content"));
					bgnbean.setBgn_image(rs.getString("bgn_image"));
					bgnbean.setBgn_link(rs.getString("bgn_link"));
					bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
					bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
					
					bList.add(bgnbean);
				}
				System.out.println("getOneAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return bList;
		}
		
		public ArrayList<bgnBean> getOnePageB(int now_page,int n,String pos) {
			ArrayList<bgnBean> bList = new ArrayList<>();
			int startNum = ((now_page-1)*12) + 1;
			int endNum = now_page*12;
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate from " + pos + " where c_num=?) a where a.num between ? and ?";
				pstmt = con.prepareStatement(sql);
				
				//3_1. ?실행
				pstmt.setInt(1, n);
				pstmt.setInt(2, startNum);
				pstmt.setInt(3, endNum);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
					//ado 어레이리스트에 클래스 저장
					bgnBean bgnbean = new bgnBean();
					bgnbean.setBgn_num(rs.getInt("bgn_num"));
					bgnbean.setC_num(rs.getInt("c_num"));
					bgnbean.setBgn_title(rs.getString("bgn_title"));
					bgnbean.setBgn_content(rs.getString("bgn_content"));
					bgnbean.setBgn_image(rs.getString("bgn_image"));
					bgnbean.setBgn_link(rs.getString("bgn_link"));
					bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
					bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
					
					bList.add(bgnbean);
				}
				System.out.println("getOneAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return bList;
		}
		
		//입력된 주소데이터를 데이터베이스에 추가하는 메소드 
		public void insertBgn(bgnBean bgnbean) {
			connect_CP();
			
			try {
				//3. sql문 작성
				//bgn_num, c_num, bgn_title, bgn_content,bgn_image
				//bgn_link, bgn_startDate, bgn_endDate
				//bgn_num --> adde_seq(자동증가기능이용)
				String sql = "insert into bgn(bgn_num, c_num, bgn_title, bgn_content, bgn_image, bgn_link, bgn_startDate, bgn_endDate, bgn_comp) select bgn_num.nextval,?,?,?,?,?,?,?,? from dual a where not exists(select 0 from bgn where bgn_link = ?)";
				pstmt = con.prepareStatement(sql);
				//? 채우기
				pstmt.setInt(1, bgnbean.getC_num());
				pstmt.setString(2, bgnbean.getBgn_title());
				pstmt.setString(3, bgnbean.getBgn_content());
				pstmt.setString(4, bgnbean.getBgn_image());
				pstmt.setString(5, bgnbean.getBgn_link());
				pstmt.setString(6, bgnbean.getBgn_startDate());
				pstmt.setString(7, bgnbean.getBgn_endDate());
				pstmt.setString(8, bgnbean.getBgn_comp());
				pstmt.setString(9, bgnbean.getBgn_link());
				
				//4. sql문 실행 및 결과
				pstmt.executeUpdate();
				System.out.println("insertAddr() : 오라클 DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			setView();
			disconnect();
		}
		
		//데이터베이스로부터 전체 봉사(b) 주소록을 읽어오는 메소드
		//1:청소년 2:vms 3:1365 4:자체
		public ArrayList<bgnBean> getAllB(){
			ArrayList<bgnBean> bList = new ArrayList<>();
			
			//1. 데이터베이스 연결
			connect_CP();
			
			//2. SQL 처리
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				//봉사 크롤링 번호는 1,2,3,4로 설정했기 때문에 c_num이 1~4인 것만 가져오고
				//(4는 자체) startDate를 기준으로 정렬
				String sql = "select * from new_bgn where c_num between 1 and 4 order by bgn_startDate";
				pstmt = con.prepareStatement(sql);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
					//ado 어레이리스트에 클래스 저장
					bgnBean bgnbean = new bgnBean();
					pstmt.setInt(1, bgnbean.getC_num());
					pstmt.setString(2, bgnbean.getBgn_title());
					pstmt.setString(3, bgnbean.getBgn_content());
					pstmt.setString(4, bgnbean.getBgn_image());
					pstmt.setString(5, bgnbean.getBgn_link());
					pstmt.setString(6, bgnbean.getBgn_startDate());
					pstmt.setString(7, bgnbean.getBgn_endDate());
					
					bList.add(bgnbean);
				}
				System.out.println("getAllEvent() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 연결해제
			disconnect();
			return bList;
		}
		
		//데이터베이스로부터 전체 기부(g) 주소록을 읽어오는 메소드
		public ArrayList<bgnBean> getAllG(){
			ArrayList<bgnBean> bList = new ArrayList<>();
			
			//1. 데이터베이스 연결
			connect_CP();
			
			//2. SQL 처리
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				//기부 크롤링 번호는 5,6,7,8,9으로 설정했기 때문에 c_num이5~9인 것만 가져오고
				//(9는 자체) 크롤링 해온 기부는 날짜가 없으므로 bgn_num 내림차순으로 정렬
				String sql = "select * from new_bgn where c_num between 5 and 9 order by bgn_num desc";
				pstmt = con.prepareStatement(sql);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
					//ado 어레이리스트에 클래스 저장
					bgnBean bgnbean = new bgnBean();
					pstmt.setInt(1, bgnbean.getC_num());
					pstmt.setString(2, bgnbean.getBgn_title());
					pstmt.setString(3, bgnbean.getBgn_content());
					pstmt.setString(4, bgnbean.getBgn_image());
					pstmt.setString(5, bgnbean.getBgn_link());
					pstmt.setString(6, bgnbean.getBgn_startDate());
					pstmt.setString(7, bgnbean.getBgn_endDate());
					
					bList.add(bgnbean);
				}
				System.out.println("getAllEvent() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 연결해제
			disconnect();
			return bList;
		}
		
		//데이터베이스로부터 전체 나눔(n) 주소록을 읽어오는 메소드
		public ArrayList<bgnBean> getAllN(){
			ArrayList<bgnBean> bList = new ArrayList<>();
			
			//1. 데이터베이스 연결
			connect_CP();
			
			//2. SQL 처리
			try {
				//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				//나눔은 크롤링을 하지 않기 때문에 null값으로 두고
				//startDate를 기준으로 정렬
				String sql = "select * from new_bgn where c_num is null order by bgn_startDate";
				pstmt = con.prepareStatement(sql);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
					//ado 어레이리스트에 클래스 저장
					bgnBean bgnbean = new bgnBean();
					pstmt.setInt(1, bgnbean.getC_num());
					pstmt.setString(2, bgnbean.getBgn_title());
					pstmt.setString(3, bgnbean.getBgn_content());
					pstmt.setString(4, bgnbean.getBgn_image());
					pstmt.setString(5, bgnbean.getBgn_link());
					pstmt.setString(6, bgnbean.getBgn_startDate());
					pstmt.setString(7, bgnbean.getBgn_endDate());
					
					bList.add(bgnbean);
				}
				System.out.println("getAllEvent() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 연결해제
			disconnect();
			return bList;
		}
		
		//수정된 주소록의 데이터를 bgnBean 클래스로 받아와서, 테이블의 해당 레코드를 업데이트(update) 합니다.
		public void modifyBgn(bgnBean bgnbean) {
			//1. 데이터베이스 연결
			connect_CP();
			
			//2. SQL문 실행
			try {
				//2-1. sql문 작성
				//bgn_num, c_num, bgn_title, bgn_content,bgn_image
				//bgn_link, bgn_startDate, bgn_endDate
				String sql = "update bgn set c_num=?, bgn_title=?, bgn_content=?, bgn_image=?,"
						+ "bgn_link=?, bgn_startDate=?, bgn_endDate=? where bgn_num=?";
				pstmt = con.prepareStatement(sql);
				//? 채우기
				pstmt.setInt(1, bgnbean.getC_num());
				pstmt.setString(2, bgnbean.getBgn_title());
				pstmt.setString(3, bgnbean.getBgn_content());
				pstmt.setString(4, bgnbean.getBgn_image());
				pstmt.setString(5, bgnbean.getBgn_link());
				pstmt.setString(6, bgnbean.getBgn_startDate());
				pstmt.setString(7, bgnbean.getBgn_endDate());
				pstmt.setInt(8, bgnbean.getBgn_num());
				
				//2-2. sql문 실행 및 결과
				pstmt.executeQuery();
				System.out.println("ModifyAddr() : 오라클 DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			setView();
			//3. 연결 해제
			disconnect();
		}
		
		//bgn_num값에 해당되는 테이블의 레코드를 찾아서 삭제하는 메소드
		public void deleteBgn(int bgn_num) {
			//1.데이터베이스 연결
			connect_CP();
			
			//2. SQL실행
			try {
				//2-2. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "delete from bgn where bgn_num=?";
				pstmt = con.prepareStatement(sql);
				
				//3_1. ?실행
				pstmt.setInt(1, bgn_num);
				
				//4. sql문 실행 및 결과
				pstmt.executeUpdate();
				System.out.println("deleteAddr() : DB 처리 완료");
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			setView();
			//3. 베이터베이스 연결 해제
			disconnect();
		}
		
		public int count() {
			int c=0;
			connect_CP();
			try {
				//2-2. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "select count(*) from new_bgn";
				pstmt = con.prepareStatement(sql);
				
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//c = Integer.parseInt(rs.toString());
					//pstmt.setInt(0, c);
					c = rs.getInt("count(*)");
					System.out.println("count() : " + c);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return c;
		}
		
		public int countB(int n,String pos) {
			int c=0;
			connect_CP();
			try {
				//2-2. sql문 작성 : 테이블에 저장된 데이터 읽어오기
				String sql = "select count(*) from " + pos + " where c_num = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, n);
				//4. sql문 실행 및 결과
				rs = pstmt.executeQuery();
				while(rs.next()){
					//c = Integer.parseInt(rs.toString());
					//pstmt.setInt(0, c);
					c = rs.getInt("count(*)");
					System.out.println("count() : " + c);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//3. 베이터베이스 연결 해제
			disconnect();
			return c;
		}
		//기부 각 페이지에서 검색
				public ArrayList<bgnBean> getSearchGD(int now_page, String pos,String s,int n) {
					if(pos.equals("new_bgn")) {
						pos = "order by bgn_num desc";
					}else if(pos.equals("end_bgn")) {
						pos = "order by bgn_num asc";
					}
					ArrayList<bgnBean> bList = new ArrayList<>();
					int startNum = ((now_page-1)*12) + 1;
					int endNum = now_page*12;
					//1.데이터베이스 연결
					connect_CP();
					
					//2. SQL실행
					try {
						//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
						String sql = "select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate, bgn_comp from bgn where c_num=? and bgn_title LIKE '%" + s + "%'" + pos + ") a where a.num between ? and ?";
						pstmt = con.prepareStatement(sql);

						//3_1. ?실행
						pstmt.setInt(1, n);
						pstmt.setInt(2, startNum);
						pstmt.setInt(3, endNum);
						
						//4. sql문 실행 및 결과
						rs = pstmt.executeQuery();
						while(rs.next()){
							//register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
							//ado 어레이리스트에 클래스 저장
							bgnBean bgnbean = new bgnBean();
							bgnbean.setBgn_num(rs.getInt("bgn_num"));
							bgnbean.setC_num(rs.getInt("c_num"));
							bgnbean.setBgn_title(rs.getString("bgn_title"));
							bgnbean.setBgn_content(rs.getString("bgn_content"));
							bgnbean.setBgn_image(rs.getString("bgn_image"));
							bgnbean.setBgn_link(rs.getString("bgn_link"));
							bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
							bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
							bgnbean.setBgn_comp(rs.getString("bgn_comp"));
							
							bList.add(bgnbean);
						}
						System.out.println("getOneAddr() : DB 처리 완료");
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					//3. 베이터베이스 연결 해제
					disconnect();
					return bList;
				}
				
				//기부 각 페이지에서 검색한 글 갯수
				public int getCountGD(String s,int n) {
					int c = 0;
					//1.데이터베이스 연결
					connect_CP();
					
					//2. SQL실행
					try {
						//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
						String sql = "SELECT count(*) FROM bgn WHERE bgn_title LIKE '%" + s + "%' and c_num=?";
						pstmt = con.prepareStatement(sql);

						//3_1. ?실행
						pstmt.setInt(1, n);
						
						//4. sql문 실행 및 결과
						rs = pstmt.executeQuery();
						while(rs.next()){
							c = rs.getInt("count(*)");
							System.out.println("count() : " + c);
						}
						System.out.println("getOneAddr() : DB 처리 완료");
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					//3. 베이터베이스 연결 해제
					disconnect();
					return c;
				}	
				public int getCountASG(String s) {
					int c = 0;
					//1.데이터베이스 연결
					connect_CP();
					
					//2. SQL실행
					try {
						//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
						String sql = "SELECT count(*) FROM bgn WHERE bgn_title LIKE '%" + s + "%' and c_num between 11 and 14";
						pstmt = con.prepareStatement(sql);

						//3_1. ?실행
						//pstmt.setString(1, s);
						
						//4. sql문 실행 및 결과
						rs = pstmt.executeQuery();
						while(rs.next()){
							c = rs.getInt("count(*)");
							System.out.println("count() : " + c);
						}
						System.out.println("getOneAddr() : DB 처리 완료");
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					//3. 베이터베이스 연결 해제
					disconnect();
					return c;
				}	
				
				public int getCountASB(String s) {
					int c = 0;
					//1.데이터베이스 연결
					connect_CP();
					
					//2. SQL실행
					try {
						//3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
						String sql = "SELECT count(*) FROM bgn WHERE bgn_title LIKE '%" + s + "%' and c_num between 1 and 4";
						pstmt = con.prepareStatement(sql);

						//3_1. ?실행
						//pstmt.setString(1, s);
						
						//4. sql문 실행 및 결과
						rs = pstmt.executeQuery();
						while(rs.next()){
							c = rs.getInt("count(*)");
							System.out.println("count() : " + c);
						}
						System.out.println("getOneAddr() : DB 처리 완료");
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					//3. 베이터베이스 연결 해제
					disconnect();
					return c;
				}	
}
