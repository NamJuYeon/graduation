package dona;

public class bgnBean {
	public int bgn_num; //PK
	public int c_num;
	public String bgn_title;
	public String bgn_content;
	public String bgn_image;
	public String bgn_link;
	public String bgn_startDate;
	public String bgn_endDate;
	public String bgn_comp;
	
	public String getBgn_comp() {
		return bgn_comp;
	}
	public void setBgn_comp(String bgn_comp) {
		this.bgn_comp = bgn_comp;
	}
	public int getBgn_num() {
		return bgn_num;
	}
	public void setBgn_num(int bgn_num) {
		this.bgn_num = bgn_num;
	}
	public int getC_num() {
		return c_num;
	}
	public void setC_num(int c_num) {
		this.c_num = c_num;
	}
	public String getBgn_title() {
		return bgn_title;
	}
	public void setBgn_title(String bgn_title) {
		this.bgn_title = bgn_title;
	}
	public String getBgn_content() {
		return bgn_content;
	}
	public void setBgn_content(String bgn_content) {
		this.bgn_content = bgn_content;
	}
	public String getBgn_image() {
		return bgn_image;
	}
	public void setBgn_image(String bgn_image) {
		this.bgn_image = bgn_image;
	}
	public String getBgn_link() {
		return bgn_link;
	}
	public void setBgn_link(String bgn_link) {
		this.bgn_link = bgn_link;
	}
	public String getBgn_startDate() {
		return bgn_startDate;
	}
	public void setBgn_startDate(String bgn_startDate) {
		this.bgn_startDate = bgn_startDate;
	}
	public String getBgn_endDate() {
		return bgn_endDate;
	}
	public void setBgn_endDate(String bgn_endDate) {
		this.bgn_endDate = bgn_endDate;
	}
}
