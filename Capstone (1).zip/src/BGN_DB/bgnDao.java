package BGN_DB;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import dona.bgnBean;

public class bgnDao {
   PreparedStatement pstmt = null;
   ResultSet rs = null;
   Connection con = null;
   
   //커넥션풀을 이용한 데이터베이스 연결 메소드 선언
   public void connect_CP() {
      try {
         //1. Context.xml에 접근
         Context initctx = new InitialContext();
         
         //2. source 태그의 name과 type 속성을 이용하여
         //DataSource 객체 생성
         DataSource ds = (DataSource)initctx.lookup("java:/comp/env/jdbc/pool");
         
         //3. 커넥션 풀에서 커넥션 할당 받기
         con = ds.getConnection();
      }catch (NamingException e) {
         e.printStackTrace();
      }catch (SQLException e) {
         e.printStackTrace();
      }
   }

   //데이터베이스 연결 해제 및 자원 해제
   public void disconnect() {
      //5. 자원 해제
      try {
         if( con != null) con.close();
         if( pstmt != null) pstmt.close();
         if( rs != null ) rs.close();
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }
   
   
   
   
   //num을 이용하여 하나의 주소정보를 리턴하는 메소드
         public BGN_DB.bgnBean getOneBgn(int bgn_num){
            BGN_DB.bgnBean bgnbean = new BGN_DB.bgnBean();
            //1. 데이터베이스 연결
            connect_CP();      
            //2. SQL 실행      
            try {
               //3. sql문 작성 : 테이블에 저장된 데이터 읽어오기 
               String sql ="select * from bgn where bgn_num=?";
               pstmt = con.prepareStatement(sql);         
               //3.1 ? 설정
               pstmt.setInt(1,bgn_num);         
               //4. sql문 실행 및 결과 
               rs = pstmt.executeQuery();      
               while(rs.next()){
                  //bgnBean 클래스 선언하고
                  //해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장                        
                  bgnbean.setBgn_title(rs.getString("bgn_title"));
                  bgnbean.setBgn_content(rs.getString("bgn_content"));
                  bgnbean.setBgn_image(rs.getString("bgn_image"));
                  bgnbean.setBgn_link(rs.getString("bgn_link"));
                  bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
                  bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
                  bgnbean.setBgn_comp(rs.getString("bgn_comp"));
               }
               System.out.println("getOneBgn(): 오라클 DB 처리 완료 !!");      
                     
            } catch (SQLException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
            }   
            
            //3. 데이터베이스 연결 해제
            disconnect();
            return bgnbean;   
         }
   
   
   
   
   //bgn_num을 이용하여 하나의 주소정보를 리턴라는 메소드
    public ArrayList<BGN_DB.bgnBean> getOnePageMain(int nowPage, String pos) {
      if(pos.equals("new_bgn")) {
         pos = "order by bgn_num desc";
      }else if(pos.equals("end_bgn")) {
         pos = "order by bgn_num asc";
      }
       ArrayList<BGN_DB.bgnBean> bList = new ArrayList<>();
       int startNum = ((nowPage-1)*12) + 1;
       int endNum = nowPage*12;
       //1.데이터베이스 연결
       connect_CP();
       
       //2. SQL실행
       try {
          //3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
          String sql = "select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate, bgn_comp from bgn where c_num between 11 and 14 " + pos + ") a where a.num between ? and ?";
          //select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate from new_bgn) a where a.num between 12 and 24 ;
          pstmt = con.prepareStatement(sql);
          
          //3_1. ?실행
          pstmt.setInt(1, startNum);
          pstmt.setInt(2, endNum);
          
          //4. sql문 실행 및 결과
          rs = pstmt.executeQuery();
          while(rs.next()){
             //register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
             //ado 어레이리스트에 클래스 저장
             BGN_DB.bgnBean bgnbean = new BGN_DB.bgnBean();
             bgnbean.setBgn_num(rs.getInt("bgn_num"));
             bgnbean.setC_num(rs.getInt("c_num"));
             bgnbean.setBgn_title(rs.getString("bgn_title"));
             bgnbean.setBgn_content(rs.getString("bgn_content"));
             bgnbean.setBgn_image(rs.getString("bgn_image"));
             bgnbean.setBgn_link(rs.getString("bgn_link"));
             bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
             bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
             bgnbean.setBgn_comp(rs.getString("bgn_comp"));

             bList.add(bgnbean);
          }
          System.out.println("getOneAddr() : DB 처리 완료");
          
       } catch (SQLException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
       }
       
       //3. 베이터베이스 연결 해제
       disconnect();
       return bList;
    }
    
    
    
    
    
    
  //bgn_num을 이용하여 하나의 주소정보를 리턴라는 메소드
    public ArrayList<BGN_DB.bgnBean> getOneGive(int num, int nowPage, String pos) {
      if(pos.equals("new_bgn")) {
         pos = "order by bgn_num desc";
      }else if(pos.equals("end_bgn")) {
         pos = "order by bgn_num asc";
      }
       ArrayList<BGN_DB.bgnBean> bList = new ArrayList<>();
       int startNum = ((nowPage-1)*12) + 1;
       int endNum = nowPage*12;
       //1.데이터베이스 연결
       connect_CP();
       
       //2. SQL실행
       try {
          //3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
          String sql = "select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate, bgn_comp from bgn where c_num = ? " + pos + ") a where a.num between ? and ?";
          //select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate from new_bgn) a where a.num between 12 and 24 ;
          pstmt = con.prepareStatement(sql);
          
          //3_1. ?실행
          pstmt.setInt(1, num);
          pstmt.setInt(2, startNum);
          pstmt.setInt(3, endNum);
          
          //4. sql문 실행 및 결과
          rs = pstmt.executeQuery();
          while(rs.next()){
             //register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
             //ado 어레이리스트에 클래스 저장
             BGN_DB.bgnBean bgnbean = new BGN_DB.bgnBean();
             bgnbean.setBgn_num(rs.getInt("bgn_num"));
             bgnbean.setC_num(rs.getInt("c_num"));
             bgnbean.setBgn_title(rs.getString("bgn_title"));
             bgnbean.setBgn_content(rs.getString("bgn_content"));
             bgnbean.setBgn_image(rs.getString("bgn_image"));
             bgnbean.setBgn_link(rs.getString("bgn_link"));
             bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
             bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
             bgnbean.setBgn_comp(rs.getString("bgn_comp"));

             bList.add(bgnbean);
          }
          System.out.println("getOneAddr() : DB 처리 완료");
          
       } catch (SQLException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
       }
       
       //3. 베이터베이스 연결 해제
       disconnect();
       return bList;
    }
    
    
    
    
    
    
       //bgn_num을 이용하여 하나의 주소정보를 리턴라는 메소드
        public ArrayList<BGN_DB.bgnBean> getOnePage(int now_page, String pos) {
           ArrayList<BGN_DB.bgnBean> bList = new ArrayList<>();
           int startNum = ((now_page-1)*12) + 1;
           int endNum = now_page*12;
           //1.데이터베이스 연결
           connect_CP();
           
           //2. SQL실행
           try {
              //3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
              String sql = "select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate from bgn where c_num between 11 and 14 " + pos + ") a where a.num between ? and ?";
              //select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate from new_bgn) a where a.num between 12 and 24 ;
              pstmt = con.prepareStatement(sql);
              
              //3_1. ?실행
              pstmt.setInt(1, startNum);
              pstmt.setInt(2, endNum);
              
              //4. sql문 실행 및 결과
              rs = pstmt.executeQuery();
              while(rs.next()){
                 //register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
                 //ado 어레이리스트에 클래스 저장
                 BGN_DB.bgnBean bgnbean = new BGN_DB.bgnBean();
                 bgnbean.setBgn_num(rs.getInt("bgn_num"));
                 bgnbean.setC_num(rs.getInt("c_num"));
                 bgnbean.setBgn_title(rs.getString("bgn_title"));
                 bgnbean.setBgn_content(rs.getString("bgn_content"));
                 bgnbean.setBgn_image(rs.getString("bgn_image"));
                 bgnbean.setBgn_link(rs.getString("bgn_link"));
                 bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
                 bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
                 
                 bList.add(bgnbean);
              }
              System.out.println("getOneAddr() : DB 처리 완료");
              
           } catch (SQLException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
           }
           
           //3. 베이터베이스 연결 해제
           disconnect();
           return bList;
        }
    
    
    
    public ArrayList<BGN_DB.bgnBean> getOnePageB(int now_page,int n,String pos) {
        ArrayList<BGN_DB.bgnBean> bList = new ArrayList<>();
        int startNum = ((now_page-1)*12) + 1;
        int endNum = now_page*12;
        //1.데이터베이스 연결
        connect_CP();
        
        //2. SQL실행
        try {
           //3. sql문 작성 : 테이블에 저장된 데이터 읽어오기
           String sql = "select * from (select rownum as num, bgn_num, c_num, bgn_title, bgn_content,bgn_image,bgn_link, bgn_startDate, bgn_endDate from " + pos + " where c_num=?) a where a.num between ? and ?";
           pstmt = con.prepareStatement(sql);
           
           //3_1. ?실행
           pstmt.setInt(1, n);
           pstmt.setInt(2, startNum);
           pstmt.setInt(3, endNum);
           
           //4. sql문 실행 및 결과
           rs = pstmt.executeQuery();
           while(rs.next()){
              //register_DO 클래스 선언하고 해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
              //ado 어레이리스트에 클래스 저장
              BGN_DB.bgnBean bgnbean = new BGN_DB.bgnBean();
              bgnbean.setBgn_num(rs.getInt("bgn_num"));
              bgnbean.setC_num(rs.getInt("c_num"));
              bgnbean.setBgn_title(rs.getString("bgn_title"));
              bgnbean.setBgn_content(rs.getString("bgn_content"));
              bgnbean.setBgn_image(rs.getString("bgn_image"));
              bgnbean.setBgn_link(rs.getString("bgn_link"));
              bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
              bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
              
              bList.add(bgnbean);
           }
           System.out.println("getOneAddr() : DB 처리 완료");
           
        } catch (SQLException e) {
           // TODO Auto-generated catch block
           e.printStackTrace();
        }
        
        //3. 베이터베이스 연결 해제
        disconnect();
        return bList;
     }
   
   
   //입력된 주소데이터를 데이터베이스에 추가하는 메소드
   public void insertBgn(BGN_DB.bgnBean bgnbean) {
      connect_CP();
      try {
         //3. sql문 작성
         
         String sql = "insert into bgn values(bgn_num.nextval,?,?,?,?,?,?,?,?)";
         pstmt = con.prepareStatement(sql);
         
         //? 채우기
         pstmt.setInt(1, bgnbean.getC_num());
         pstmt.setString(2, bgnbean.getBgn_title());
         pstmt.setString(3, bgnbean.getBgn_content());
         pstmt.setString(4, bgnbean.getBgn_image());
         pstmt.setString(5, bgnbean.getBgn_link());
         pstmt.setString(6, bgnbean.getBgn_startDate());
         pstmt.setString(7, bgnbean.getBgn_endDate());
         pstmt.setString(8, bgnbean.getBgn_comp());
         
         //4. sql문 실행 및 결과
         pstmt.executeUpdate();
         System.out.println("insertBgn() : 오라클 DB 처리 완료");
      } catch (SQLException e) {
         e.printStackTrace();
      }
      disconnect();
   }
   
   
      
      
      
      
      
      
      //마지막으로 들어간 데이터의 bgn_num 가져오기
      public int getLastBgn_num() {
         int bgn_num = 0;
         
         connect_CP();
         try {
            //3. sql문 작성
            
            String sql = "select bgn_num from bgn where rownum = 1 order by bgn_num desc";
            pstmt = con.prepareStatement(sql);
            
            //4. sql문 실행 및 결과
            rs = pstmt.executeQuery();
            while(rs.next()) {
               bgn_num = rs.getInt("bgn_num");
            }
            System.out.println("insertBgn() : 오라클 DB 처리 완료");
         } catch (SQLException e) {
            e.printStackTrace();
         }
         disconnect();
         
         return bgn_num;
      }
      
      
      
      
      
      
      //데이터베이스로부터 전체 주소록을 읽어오는 메소드
      public ArrayList<BGN_DB.bgnBean> getAllBgn(){
         ArrayList<BGN_DB.bgnBean> bgnList = new ArrayList<>();
         //1. 데이터베이스 연결
         connect_CP();
         //2. SQL 처리
         try {
            //3. sql문 작성 : 테이블에 저장된 데이터 읽어오기 
            String sql ="select * from bgn where c_num between 11 and 13";
            pstmt = con.prepareStatement(sql);
            //4. sql문 실행 및 결과 
            rs = pstmt.executeQuery();      
            while(rs.next()){
               //addrBean 클래스 선언하고
               //해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
               //어레이리스트에 클래스 저장
               BGN_DB.bgnBean bgnbean = new BGN_DB.bgnBean();
               //num, title, date, weather, img, content
               bgnbean.setBgn_num(rs.getInt("bgn_num"));
               bgnbean.setBgn_title(rs.getString("bgn_title"));
               bgnbean.setBgn_content(rs.getString("bgn_content"));
               bgnbean.setBgn_image(rs.getString("bgn_image"));
               bgnbean.setBgn_link(rs.getString("bgn_link"));
               bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
               bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
               bgnbean.setBgn_comp(rs.getString("bgn_comp"));
               //리스트에 빈즈클래스 저장
               bgnList.add(bgnbean);            
            }
            System.out.println("getAllEvent(): 오라클 DB 처리 완료 !!");      
                        
         } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
         
         //3. 연결해제
         disconnect();
         return bgnList;
      }
      
      
      //데이터베이스로부터 전체 주소록을 읽어오는 메소드
      public ArrayList<BGN_DB.bgnBean> getAllBgnN(){
         ArrayList<BGN_DB.bgnBean> bgnList = new ArrayList<>();
         //1. 데이터베이스 연결
         connect_CP();
         //2. SQL 처리
         try {
            //3. sql문 작성 : 테이블에 저장된 데이터 읽어오기 
            String sql ="select * from bgn where c_num=21";
            pstmt = con.prepareStatement(sql);
            //4. sql문 실행 및 결과 
            rs = pstmt.executeQuery();      
            while(rs.next()){
               //addrBean 클래스 선언하고
               //해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
               //어레이리스트에 클래스 저장
               BGN_DB.bgnBean bgnbean = new BGN_DB.bgnBean();
               //num, title, date, weather, img, content
               bgnbean.setBgn_num(rs.getInt("bgn_num"));
               bgnbean.setBgn_title(rs.getString("bgn_title"));
               bgnbean.setBgn_content(rs.getString("bgn_content"));
               bgnbean.setBgn_image(rs.getString("bgn_image"));
               bgnbean.setBgn_link(rs.getString("bgn_link"));
               bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
               bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
               bgnbean.setBgn_comp(rs.getString("bgn_comp"));
               //리스트에 빈즈클래스 저장
               bgnList.add(bgnbean);            
            }
            System.out.println("getAllEvent(): 오라클 DB 처리 완료 !!");      
                        
         } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
         
         //3. 연결해제
         disconnect();
         return bgnList;
      }
      
   
               
               
      
      
      
      
      
      
      //기부사이트별로 내용 띄우는거
            public ArrayList<BGN_DB.bgnBean> getDonationOne(int num) {
                    connect_CP();
                    
                    ArrayList<BGN_DB.bgnBean> bgnList3 = new ArrayList<BGN_DB.bgnBean>();
                    
                    try {
                       //2-2. sql문 작성 : 테이블에 저장된 데이터 읽어오기
                       String sql = "select * from bgn where c_num = ?";
                       pstmt = con.prepareStatement(sql);
                       
                       pstmt.setInt(1, num);
                       //4. sql문 실행 및 결과
                       rs = pstmt.executeQuery();
                       while(rs.next()){
                        //addrBean 클래스 선언하고
                        //해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
                        //어레이리스트에 클래스 저장
                        BGN_DB.bgnBean bgnbean = new BGN_DB.bgnBean();
                        //num, title, date, weather, img, content
                        bgnbean.setBgn_num(rs.getInt("bgn_num"));
                        bgnbean.setBgn_title(rs.getString("bgn_title"));
                        bgnbean.setBgn_content(rs.getString("bgn_content"));
                        bgnbean.setBgn_image(rs.getString("bgn_image"));
                        bgnbean.setBgn_link(rs.getString("bgn_link"));
                        bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
                        bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
                        bgnbean.setBgn_comp(rs.getString("bgn_comp"));
                        //리스트에 빈즈클래스 저장
                        bgnList3.add(bgnbean);            
                     }
                    } catch (SQLException e) {
                       // TODO Auto-generated catch block
                       e.printStackTrace();
                    }
                    
                    //3. 베이터베이스 연결 해제
                    disconnect();
                    return bgnList3;
                 }
               
               
      
      
      
      
      
      
      
      //전체 글 개수 세기
      public int donationCount() {
           int c=0;
           connect_CP();
           try {
              //2-2. sql문 작성 : 테이블에 저장된 데이터 읽어오기
              String sql = "select count(*) from bgn where c_num between 11 and 14";
              pstmt = con.prepareStatement(sql);
              
              //4. sql문 실행 및 결과
              rs = pstmt.executeQuery();
              while(rs.next()){
                 //c = Integer.parseInt(rs.toString());
                 //pstmt.setInt(0, c);
                 c = rs.getInt("count(*)");
                 System.out.println("count() : " + c);
              }
           } catch (SQLException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
           }
           
           //3. 베이터베이스 연결 해제
           disconnect();
           return c;
        }      
      
      
      
      
      //기부 각 페이지 들어갔을때 글 개수
      public int donationCount222(int num) {
           int c = 0;
           connect_CP();
           
           try {
              //2-2. sql문 작성 : 테이블에 저장된 데이터 읽어오기
              String sql = "select count(*) from bgn where c_num = ?";
              pstmt = con.prepareStatement(sql);
              
              pstmt.setInt(1, num);
              
              //4. sql문 실행 및 결과
              rs = pstmt.executeQuery();
              while(rs.next()){
                 //c = Integer.parseInt(rs.toString());
                 //pstmt.setInt(0, c);
                 c = rs.getInt("count(*)");
                 System.out.println("count() : " + c);
              }
           } catch (SQLException e) {
              // TODO Auto-generated catch block
              e.printStackTrace();
           }
           
           //3. 베이터베이스 연결 해제
           disconnect();
           return c;
        }
      
      
      
      
      
      
      //메인에 4개씩 띄우는거
      public ArrayList<BGN_DB.bgnBean> getbgn3(int num) {
              connect_CP();
              
              ArrayList<BGN_DB.bgnBean> bgnList2 = new ArrayList<BGN_DB.bgnBean>();
              int a =  0;
              int b = 0;
              if(num ==1) {
                 a = 1;
                 b = 4;
              }else if(num ==2) {
                 a = 11;
                 b = 14;
              }
              try {
                 //2-2. sql문 작성 : 테이블에 저장된 데이터 읽어오기
                 String sql = "select * from bgn where (c_num  between ? and ?) and (rownum  between 1 and 4) order by bgn_num desc";
                 pstmt = con.prepareStatement(sql);
                 
                 pstmt.setInt(1, a);
                 pstmt.setInt(2, b);
                 //4. sql문 실행 및 결과
                 rs = pstmt.executeQuery();
                 while(rs.next()){
                  //addrBean 클래스 선언하고
                  //해당 클래스에 데이터베이스로부터 읽어온 데이터를 저장
                  //어레이리스트에 클래스 저장
                  BGN_DB.bgnBean bgnbean = new BGN_DB.bgnBean();
                  //num, title, date, weather, img, content
                  bgnbean.setBgn_num(rs.getInt("bgn_num"));
                  bgnbean.setBgn_title(rs.getString("bgn_title"));
                  bgnbean.setBgn_content(rs.getString("bgn_content"));
                  bgnbean.setBgn_image(rs.getString("bgn_image"));
                  bgnbean.setBgn_link(rs.getString("bgn_link"));
                  bgnbean.setBgn_startDate(rs.getString("bgn_startDate"));
                  bgnbean.setBgn_endDate(rs.getString("bgn_endDate"));
                  bgnbean.setBgn_comp(rs.getString("bgn_comp"));
                  //리스트에 빈즈클래스 저장
                  bgnList2.add(bgnbean);            
               }
              } catch (SQLException e) {
                 // TODO Auto-generated catch block
                 e.printStackTrace();
              }
              
              //3. 베이터베이스 연결 해제
              disconnect();
              return bgnList2;
           }
      
      
      
      
      
      
      
         
         
         
         
         
         
         
         
         
         
         
         
         
      
      
      
      
      
      //기부크롤링 DB에 넣음
      public void CinsertBgn() {
         
         //저장할 List 선언
         List<String> titles = new ArrayList<String>();
         List<String> urls = new ArrayList<String>();
         List<String> imgs = new ArrayList<String>();
         
         //gfoundation 코드
         for(int n=1; n<6; n++) {
            //url 할당
            String gurl = "https://www.gfound.org/bbs/board.php?bo_table=support_1&page="+n;
            String gselector = "div.bo_list";
             Document gdoc = null;
             
             try {
                 gdoc = Jsoup.connect(gurl).get(); // 1. get방식의 URL에 연결해서 가져온 값을 doc에 담는다.
             } catch (IOException e) {
                 System.out.println(e.getMessage());
             }
             
             //메인 요소 선택
             Elements gfound = gdoc.select("ul>li");
             
             //gfound title ////// title이 비어있는건 어떻게 처리 할건지ㅠㅠ...
             String gtitle = gfound.select("p.s_list_stit").html();
             String[] gtitles = gfound.select("p.s_list_stit").html().split("\n");
             for(int t=0; t<gtitles.length; t++) {
                if(gtitles[t] == ""){
                   titles.add(" ");
                }else{
                   titles.add(gtitles[t]);
                }
                
             }
             
             //gfound url
            String[] gurls = gfound.select("span.s_list_btn").html().split("\n");
            for(int u=0; u<gurls.length; u++) {
               //substring 이용해서 필요한 url 부분만 자름
               gurls[u] = gurls[u].substring(9, 92);
               urls.add(gurls[u]);
            }
            
            //gfound img
            String[] gimgs = gfound.select("div.s_list_phot>a").html().split("\n");
            for(int i=0; i<gimgs.length; i++) {
               //substring 이용해서 필요한 url 부분만 자름
               gimgs[i] = gimgs[i].substring(10, 135);
               imgs.add(gimgs[i]);
            }
             
         }
         
         //제목이 아예 없어서 하나씩 땡겨지던거 빈칸 추가해서 해결
         titles.add(26, " ");
         
         
         
            //concern 코드
            String courl = "https://www.concern.or.kr/load.asp?subPage=310#";
            String coselector = "div.bbs_thumb_list>ul";
             Document codoc = null;
             
             try {
                codoc = Jsoup.connect(courl).get(); // 1. get방식의 URL에 연결해서 가져온 값을 doc에 담는다.
             } catch (IOException e) {
                 System.out.println(e.getMessage());
             }
             
             //메인 요소 선택
             Elements concern = codoc.select(coselector);
             
             //concern title
             String[] cotitles = concern.select("li>div.cont>div.tit>a>span").html().split("\n");
             for(int t=0; t<cotitles.length; t++) {
                //indexOf로 ]기준 문자 2개로 쪼갬 쪼갠거에 "은 포함x
                int idx = cotitles[t].indexOf(']');
                //쪼갠거에서 뒤에꺼 앞에서 2번째부터 가져옴
                cotitles[t] = cotitles[t].substring(idx+2);
                titles.add(cotitles[t]);
             }
             
             //concern img
             concern.select("li>a>div.over").remove();
            String[] coimgs = concern.select("li>a").html().split("\n");
            for(int i=0; i<coimgs.length; i++) {
               coimgs[i] = "https://www.concern.or.kr" + coimgs[i].substring(10, 63);
               imgs.add(coimgs[i]);
            }
             
             //concern url
            concern.select("li>div.cont>div.tit>div.date").remove();
            concern.select("li>div.cont>div.tit>a>span").remove();
            String[] courls = concern.select("li>div.cont>div.tit").html().split("\n");
            for(int u=0; u<courls.length; u++) {
               if(u<2) {
                  courls[u] = "https://www.concern.or.kr" + courls[u].substring(63, 174);
                  //replace로 "랑 ' 제거
                  courls[u] = courls[u].replace('"',' ');
                  courls[u] = courls[u].replace("'"," ");
                  urls.add(courls[u]);
               }else {
                  courls[u] = "https://www.concern.or.kr" + courls[u].substring(10, 91);
                  urls.add(courls[u]);
               }
               
            }
            
            
         
         //withgo 코드
         
         for(int wg=1; wg<3; wg++) {
            String wurl = "http://www.withgo.or.kr/campaign/story_cam.asp?strArea=B&intCate=&intStat=1&intPage="+wg+"#";
            String wselector = "div.camp_list>ul.clearfix";
            Document wdoc = null;
                
            try {
               wdoc = Jsoup.connect(wurl).get(); // 1. get방식의 URL에 연결해서 가져온 값을 doc에 담는다.
            } catch (IOException e) {
               System.out.println(e.getMessage());
            }
                
            //메인 요소 선택
            Elements withgo = wdoc.select(wselector);
                
            //withgo title
            String[] wtitles = withgo.select("li>a>p.tit").html().split("\n");
            for(int t=0; t<wtitles.length; t++) {
               titles.add(wtitles[t]);
            }
            
            //withgo img
            String[] wimgs = withgo.select("li>a>div.thum").html().split("\n");
            for(int i=0; i<wtitles.length; i++) {
               wimgs[i] = "http://www.withgo.or.kr" + wimgs[i].substring(10,54);
               int idx = wimgs[i].indexOf('"');
               wimgs[i] = wimgs[i].substring(0,idx);
               imgs.add(wimgs[i]);
            }
               
                
            //withgo url
            withgo.select("li>span").remove();
            withgo.select("li>div").remove();
            withgo.select("li>a>ul").remove();
            withgo.select("li>a>div.thum").remove();
            String[] wurls = withgo.select("li").html().split("\n");
            for(int u=0; u<wtitles.length; u++) {
               wurls[u] = "http://www.withgo.or.kr/campaign" + wurls[u].substring(10, 98).replace('"',' ');
               urls.add(wurls[u]);
            }
               
         }
         
         
         
         
         
         
         
         for(int p=0; p<titles.size(); p++) {
            
            String com = "";
            if(urls.get(p).contains("gfound")){
               com = "지파운데이션";
            }else if(urls.get(p).contains("concern")){
               com = "컨선월드와이드";
            }else if(urls.get(p).contains("withgo")){
               com = "함께하는 사랑밭";
            }
            
            int cnum = 0;
            if(urls.get(p).contains("gfound")){
               cnum = 11;
            }else if(urls.get(p).contains("concern")){
               cnum = 12;
            }else if(urls.get(p).contains("withgo")){
               cnum = 13;
            }
            
            
            connect_CP();
            try {
               //3. sql문 작성
               
               String sql = "insert into bgn(bgn_num, c_num, bgn_title, bgn_content, bgn_image, bgn_link, bgn_startDate, bgn_endDate, bgn_comp) select bgn_num.nextval,?,?,?,?,?,?,?,? from dual a where not exists(select 0 from bgn where bgn_link = ?)";
               pstmt = con.prepareStatement(sql);
               
               //? 채우기
               pstmt.setInt(1, cnum);
               pstmt.setString(2, titles.get(p));
               pstmt.setString(3, "");
               pstmt.setString(4, imgs.get(p));
               pstmt.setString(5, urls.get(p));
               pstmt.setString(6, "");
               pstmt.setString(7, "");
               pstmt.setString(8, com);
               pstmt.setString(9, urls.get(p));
               
               //4. sql문 실행 및 결과
               pstmt.executeUpdate();
               System.out.println("CinsertBgn() : 오라클 DB 처리 완료");
            } catch (SQLException e) {
               e.printStackTrace();
            }
            disconnect();
         }
      }
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      

}